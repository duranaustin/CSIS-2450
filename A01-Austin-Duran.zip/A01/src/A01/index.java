package A01;

/**
 * index class to start off A01 Assignment
 *
 * @Author Austin Duran 5/16/2019
 */
public class index {

    /**
     * main to start off program
     * @param args
     */
    public static void main(String[]args){
        A01UI start = new A01UI();
    }
}
